import client from '@sanity/client';
export default client({
    projectId: 'p0ifd5ok',
    dataset: 'production',
})